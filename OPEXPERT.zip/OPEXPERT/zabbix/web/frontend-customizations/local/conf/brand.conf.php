<?php

return [
  'BRAND_HELP_URL' => 'https://opexpert.com/contact/',
  'BRAND_LOGO' => '../../assets/img/opexpert-company-logo.png',
  'BRAND_FOOTER' => 'OpExpert Network Monitoring System',
];

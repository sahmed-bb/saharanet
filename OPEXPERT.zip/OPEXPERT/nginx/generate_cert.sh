#!/bin/bash
echo "Generating a certificate..."
ROOTDIR="./config"
sudo mkdir -p ${ROOTDIR}/{private,certs}
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout ${ROOTDIR}/private/nginx-selfsigned.key -out ${ROOTDIR}/certs/nginx-selfsigned.crt

echo "Generating a Diffie-Hellman (DH) group for negotiation..."
sudo openssl dhparam -out ${ROOTDIR}/conf.d/dhparam.pem 4096

echo "Creating/Appending SSL parameters to nginx conf.d directory..."

sudo tee -a ${ROOTDIR}/conf.d/ssl_params.conf << END
ssl_protocols TLSv1.3;# Requires nginx >= 1.13.0 else use TLSv1.2
ssl_prefer_server_ciphers on;
ssl_dhparam /etc/nginx/conf.d/dhparam.pem; # openssl dhparam -out /etc/nginx/conf.d/dhparam.pem 4096
ssl_ciphers EECDH+AESGCM:EDH+AESGCM;
ssl_ecdh_curve secp384r1; # Requires nginx >= 1.1.0
ssl_session_timeout  10m;
ssl_session_cache shared:SSL:10m;
ssl_session_tickets off; # Requires nginx >= 1.5.9
ssl_stapling on; # Requires nginx >= 1.3.7
ssl_stapling_verify on; # Requires nginx => 1.3.7
resolver $DNS-IP-1 $DNS-IP-2 valid=300s;
resolver_timeout 5s;
add_header Strict-Transport-Security "max-age=63072000; includeSubDomains; preload";
add_header X-Frame-Options DENY;
add_header X-Content-Type-Options nosniff;
add_header X-XSS-Protection "1; mode=block";
END

echo "Creating a template configuration, change it according to your requirements after this process..."
sudo tee ${ROOTDIR}/conf.d/ssl_https.conf << END
server {
    listen       443 ssl;
    server_name  <your_domain_name>;
    error_log   /var/log/nginx/opexpert_error.log;
    access_log   /var/log/nginx/opexpert_access.log;

    location / {
        proxy_redirect     off;
        proxy_set_header   Host $host;
        proxy_set_header   X-Real-IP $remote_addr;
        proxy_set_header   X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Host $server_name;
        proxy_pass http://<some_url>;
    }

    ssl_certificate /etc/nginx/certs/nginx-selfsigned.crt;
    ssl_certificate_key /etc/nginx/private/nginx-selfsigned.key;
}
END

echo "Creating a file for HTTPS redirection..."
sudo tee ${ROOTDIR}/conf.d/ssl_redirection.conf << END
server {
        listen 80 default_server;
        server_name _;

        return 301 https://$host$request_uri;
    }
END
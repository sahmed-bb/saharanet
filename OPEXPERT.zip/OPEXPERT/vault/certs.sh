#!/bin/bash

# Function to prompt for input
prompt_for_input() {
    read -p "$1: " input
    echo $input
}

# Function to check the success of the last command and exit if it failed
check_success() {
    if [ $? -ne 0 ]; then
        echo "Error occurred. Exiting."
        exit 1
    fi
}

# Check if Docker is installed
if ! [ -x "$(command -v docker)" ]; then
    echo "Docker is not installed. Installing Docker..."
    sudo dnf install -y dnf-plugins-core
    check_success
    sudo dnf config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
    check_success
    sudo dnf install -y docker-ce docker-ce-cli containerd.io
    check_success
    sudo systemctl start docker
    sudo systemctl enable docker
    check_success
    sudo usermod -aG docker $(whoami)
    check_success
    echo "Docker installation completed."
else
    echo "Docker is already installed."
fi

# Download the zip file
wget http://130.162.172.83/vault-setup.zip
check_success

# Unzip the file and navigate into the Vault directory
echo -e "\033[0;34mUnzipping vault-setup.zip and navigating to the Vault directory...\033[0m"
unzip vault-setup.zip -d vault-setup
check_success
cd vault-setup

# Change ownership and modify permissions for vault-config.json
echo -e "\033[0;34mChanging ownership and modifying permissions for vault-config.json...\033[0m"
sudo chown 100:100 vault/config/vault-config.json
check_success
sudo chmod 600 vault/config/vault-config.json
check_success

# Fix permissions for Vault data directory
echo -e "\033[0;34mFixing permissions for Vault data directory...\033[0m"
sudo mkdir -p vault/data
sudo chown -R 100:100 vault/data
check_success

# Start the docker-compose.yml file
echo -e "\033[0;34mStarting Docker Compose services...\033[0m"
docker compose up -d
check_success

# Wait a few seconds to ensure the services are up and running
sleep 10

# Install jq in the container
docker exec -it vault sh -c "
    apk add --no-cache jq
"
check_success

# Execute a command to enter the container and initialize Vault
echo -e "\033[0;34mEntering the Vault container and initializing Vault...\033[0m"
docker exec -it vault sh -c "
    export VAULT_ADDR=http://140.238.123.59:8200;
    export VAULT_SKIP_VERIFY=true;
    vault operator init -key-shares=1 -key-threshold=1 > /vault/init_output.txt;
    cat /vault/init_output.txt;
"
check_success

# Check if init_output.txt exists and extract Unseal Keys and Root Token
if docker exec -it vault sh -c "test -f /vault/init_output.txt"; then
    UNSEAL_KEYS=$(docker exec -it vault sh -c "grep 'Unseal Key' /vault/init_output.txt | awk '{print \$NF}'")
    ROOT_TOKEN=$(docker exec -it vault sh -c "grep 'Initial Root Token' /vault/init_output.txt | awk '{print \$NF}'")
else
    echo -e "\033[0;31mError: /vault/init_output.txt not found.\033[0m"
    exit 1
fi

# Unseal Vault Keys
echo -e "\033[0;34mUnsealing Vault...\033[0m"
for key in $UNSEAL_KEYS; do
    echo -e "\033[0;34mUnsealing with key: $key\033[0m"
    docker exec -it vault sh -c "
        export VAULT_ADDR=http://140.238.123.59:8200;
        export VAULT_SKIP_VERIFY=true;
        vault operator unseal $key
    "
    if [ $? -ne 0 ]; then
        echo -e "\033[0;31mError occurred at Unsealing Vault with key $key\033[0m"
        exit 1
    fi
done

# Login to Vault using Root Token
echo -e "\033[0;34mLogging in to Vault with the Root Token...\033[0m"
docker exec -it vault sh -c "
    export VAULT_ADDR=http://140.238.123.59:8200;
    export VAULT_SKIP_VERIFY=true;
    vault login $ROOT_TOKEN
"
check_success

# Enable the PKI secrets engine
docker exec -it vault sh -c "
    export VAULT_ADDR=http://140.238.123.59:8200;
    export VAULT_SKIP_VERIFY=true;
    vault secrets enable pki
"
check_success

# Configure the CA and generate the root certificate
docker exec -it vault sh -c "
    export VAULT_ADDR=http://140.238.123.59:8200;
    export VAULT_SKIP_VERIFY=true;
    vault write pki/root/generate/internal common_name=\"example.com\" ttl=8760h
"
check_success

# Prompt for domain and subdomain
DOMAIN=$(prompt_for_input "Enter the domain name")
SUBDOMAIN=$(prompt_for_input "Enter the subdomain name")

# Configure the roles for the specific domain
docker exec -it vault sh -c "
    export VAULT_ADDR=http://140.238.123.59:8200;
    export VAULT_SKIP_VERIFY=true;
    vault write pki/roles/$DOMAIN allowed_domains=\"$DOMAIN\" allow_subdomains=true max_ttl=\"8760h\"
"
check_success

# Generate the certificate
docker exec -it vault sh -c "
    export VAULT_ADDR=http://140.238.123.59:8200;
    export VAULT_SKIP_VERIFY=true;
    vault write pki/issue/$DOMAIN common_name=\"$SUBDOMAIN.$DOMAIN\" ttl=\"720h\" > /vault/certs.txt
"
check_success

# Debug: Display the contents of certs.txt inside the container
docker exec -it vault sh -c "
    cat /vault/certs.txt
"

# Retrieve and save the certificate and key
docker exec -it vault sh -c "
    cat /vault/certs.txt | jq -r '.data.certificate' > /vault/$SUBDOMAIN.$DOMAIN.crt;
    cat /vault/certs.txt | jq -r '.data.private_key' > /vault/$SUBDOMAIN.$DOMAIN.key;
"

# Debug: Display the contents of the certificate and key files inside the container
docker exec -it vault sh -c "
    echo 'Certificate:';
    cat /vault/$SUBDOMAIN.$DOMAIN.crt;
    echo 'Private Key:';
    cat /vault/$SUBDOMAIN.$DOMAIN.key;
"

# Copy the certificate and key from the container to the host
docker cp vault:/vault/$SUBDOMAIN.$DOMAIN.crt .
docker cp vault:/vault/$SUBDOMAIN.$DOMAIN.key .

# Debug: Display the contents of the certificate and key files on the host
echo 'Certificate on host:';
cat $SUBDOMAIN.$DOMAIN.crt;
echo 'Private Key on host:';
cat $SUBDOMAIN.$DOMAIN.key;

echo -e "\033[0;32mSSL certificates generated and saved as $SUBDOMAIN.$DOMAIN.crt and $SUBDOMAIN.$DOMAIN.key\033[0m"

#!/bin/bash

# Function to prompt for input
prompt_for_input() {
    read -p "$1: " input
    echo $input
}

# Function to generate a random password with letters and numbers only
generate_password() {
    tr -dc 'A-Za-z0-9' < /dev/urandom | head -c 16
}

# Function to check the success of the last command and exit if it failed
check_success() {
    if [ $? -ne 0 ]; then
        echo "Error occurred. Exiting."
        exit 1
    fi
}

# Check if Docker is installed
if ! [ -x "$(command -v docker)" ]; then
    echo "Docker is not installed. Installing Docker..."
    sudo dnf install -y dnf-plugins-core
    check_success
    sudo dnf config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
    check_success
    sudo dnf install -y docker-ce docker-ce-cli containerd.io
    check_success
    sudo systemctl start docker
    sudo systemctl enable docker
    check_success
    sudo usermod -aG docker $(whoami)
    check_success
    echo "Docker installation completed."
else
    echo "Docker is already installed."
fi

# Download the zip file
wget http://130.162.172.83/vault-setup.zip
check_success "Download Complete"

# Unzip the file and navigate into the Vault directory
echo -e "\033[0;34mUnzipping vault-setup.zip and navigating to the Vault directory...\033[0m"
unzip vault-setup.zip -d vault-setup
check_success "Unzipping vault-setup.zip"
cd vault-setup

# Change ownership and modify permissions for vault-config.json
echo -e "\033[0;34mChanging ownership and modifying permissions for vault-config.json...\033[0m"
sudo chown 100:100 vault/config/vault-config.json
check_success "Changing ownership of vault-config.json"
sudo chmod 600 vault/config/vault-config.json
check_success "Modifying permissions of vault-config.json"

# Fix permissions for Vault data directory
echo -e "\033[0;34mFixing permissions for Vault data directory...\033[0m"
sudo mkdir -p vault/data
sudo chown -R 100:100 vault/data
check_success "Fixing permissions for Vault data directory"

# Start the docker-compose.yml file
echo -e "\033[0;34mStarting Docker Compose services...\033[0m"
docker-compose up -d
check_success "Starting Docker Compose services"

# Wait a few seconds to ensure the services are up and running
sleep 10

# Install jq in the container
docker exec -it vault sh -c "
    apk add --no-cache jq
"
check_success "Installing jq in the container"

# Execute a command to enter the container and initialize Vault
echo -e "\033[0;34mEntering the Vault container and initializing Vault...\033[0m"
docker exec -it vault sh -c "
    export VAULT_ADDR=http://140.238.123.59:8200;
    export VAULT_SKIP_VERIFY=true;
    vault operator init -key-shares=1 -key-threshold=1 > /vault/init_output.txt;
    cat /vault/init_output.txt;
"
check_success "Vault initialization"

# Check if init_output.txt exists and extract Unseal Keys and Root Token
if docker exec -it vault sh -c "test -f /vault/init_output.txt"; then
    UNSEAL_KEYS=$(docker exec -it vault sh -c "grep 'Unseal Key' /vault/init_output.txt | awk '{print \$NF}'")
    ROOT_TOKEN=$(docker exec -it vault sh -c "grep 'Initial Root Token' /vault/init_output.txt | awk '{print \$NF}'")
else
    echo -e "\033[0;31mError: /vault/init_output.txt not found.\033[0m"
    exit 1
fi

# Unseal Vault Keys
echo -e "\033[0;34mUnsealing Vault...\033[0m"
for key in $UNSEAL_KEYS; do
    echo -e "\033[0;34mUnsealing with key: $key\033[0m"
    docker exec -it vault sh -c "
        export VAULT_ADDR=http://140.238.123.59:8200;
        export VAULT_SKIP_VERIFY=true;
        vault operator unseal $key
    "
    if [ $? -ne 0 ]; then
        echo -e "\033[0;31mError occurred at Unsealing Vault with key $key\033[0m"
        exit 1
    fi
done

# Login to Vault using Root Token
echo -e "\033[0;34mLogging in to Vault with the Root Token...\033[0m"
docker exec -it vault sh -c "
    export VAULT_ADDR=http://140.238.123.59:8200;
    export VAULT_SKIP_VERIFY=true;
    vault login $ROOT_TOKEN
"
check_success "Logging in to Vault with Root Token"

# Enable userpass authentication
docker exec -it vault sh -c "
    export VAULT_ADDR=http://140.238.123.59:8200;
    export VAULT_SKIP_VERIFY=true;
    vault auth enable userpass
"
check_success "Enabling userpass authentication"

# Prompt for username
VAULT_USER=$(prompt_for_input "Enter Vault username")
# Generate a password for the user
VAULT_USER_PASSWORD=$(generate_password)
echo "Vault user password: $VAULT_USER_PASSWORD"

# Create the user with the generated password
docker exec -it vault sh -c "
    export VAULT_ADDR=http://140.238.123.59:8200;
    export VAULT_SKIP_VERIFY=true;
    vault write auth/userpass/users/$VAULT_USER password=\"$VAULT_USER_PASSWORD\"
"
check_success "Creating user and setting password"

# Enable kv-v2 secrets engine at path user_$VAULT_USER
docker exec -it vault sh -c "
    export VAULT_ADDR=http://140.238.123.59:8200;
    export VAULT_SKIP_VERIFY=true;
    vault secrets enable -path=user_$VAULT_USER kv-v2
"
check_success "Enabling kv-v2 secrets engine at path user_$VAULT_USER"

# Extract the accessor ID for userpass
USERPASS_ACCESSOR=$(docker exec -it vault sh -c "
    export VAULT_ADDR=http://140.238.123.59:8200;
    export VAULT_SKIP_VERIFY=true;
    vault auth list -format=json | jq -r '.\"userpass/\".accessor'
")
check_success "Extracting userpass accessor ID"

echo "Userpass accessor: $USERPASS_ACCESSOR"

# Check if the accessor ID is empty
if [ -z "$USERPASS_ACCESSOR" ]; then
    echo "Error: USERPASS_ACCESSOR is empty"
    exit 1
fi

# Create the user_default policy directly within the container
docker exec -it vault sh -c "
    export VAULT_ADDR=http://140.238.123.59:8200;
    export VAULT_SKIP_VERIFY=true;
    vault policy write user_default - <<EOF
path \"user_{{identity.entity.aliases.${USERPASS_ACCESSOR}.name}}/*\" {
  capabilities = [\"read\", \"create\", \"update\", \"list\", \"delete\"]
}
path \"auth/userpass/users/{{identity.entity.aliases.${USERPASS_ACCESSOR}.name}}/password\" {
  capabilities = [\"update\"]
  allowed_parameters = {
    \"password\" = [],
    \"username\" = []
  }
}
EOF
"
check_success "Creating user_default policy"

# Assign the user_default policy to the user
docker exec -it vault sh -c "
    export VAULT_ADDR=http://140.238.123.59:8200;
    export VAULT_SKIP_VERIFY=true;
    vault write auth/userpass/users/$VAULT_USER policies=user_default
"
check_success "Assigning user_default policy to the user"

# Generate a password for the admin user
ADMIN_PASSWORD=$(generate_password)
echo "Admin password: $ADMIN_PASSWORD"

# Create the admin user with the generated password and assign the admin policy
docker exec -it vault sh -c "
    export VAULT_ADDR=http://140.238.123.59:8200;
    export VAULT_SKIP_VERIFY=true;
    vault write auth/userpass/users/admin password=\"$ADMIN_PASSWORD\" policies=admin-policy
"
check_success "Creating admin user and assigning admin policy"

# Create the admin policy file in the host environment
echo '
path "auth/userpass/users/*" {
  capabilities = ["create", "update", "delete", "list"]
}

path "auth/userpass/login/*" {
  capabilities = ["create", "read"]
}

path "auth/userpass/users" {
  capabilities = ["list"]
}

path "sys/policies/acl/*" {
  capabilities = ["read", "list"]
}
' > admin_policy.hcl

# Copy the admin policy file to the Vault container
docker cp admin_policy.hcl vault:/vault/admin_policy.hcl

# Write the updated policy to Vault
docker exec -it vault sh -c "
    export VAULT_ADDR=http://140.238.123.59:8200;
    export VAULT_SKIP_VERIFY=true;
    vault policy write admin-policy /vault/admin_policy.hcl
"
check_success "Writing admin policy to Vault"

# Output the required information
echo -e "\033[0;32mVault setup complete. You can now access Vault from the browser using http://140.238.123.59:8200\033[0m"
echo -e "\033[0;32m1. Unseal key(s):\033[0m"
for key in $UNSEAL_KEYS; do
    echo -e "\033[0;32m- $key\033[0m"
done
echo -e "\033[0;32m2. Vault username: $VAULT_USER\033[0m"
echo -e "\033[0;32m3. Vault user password: $VAULT_USER_PASSWORD\033[0m"
echo -e "\033[0;32m4. Admin username: admin\033[0m"
echo -e "\033[0;32m5. Admin password: $ADMIN_PASSWORD\033[0m"
echo ""
echo -e "\033[0;32mPlease keep the unseal keys and admin password in a safe secure place.\033[0m"
